<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>O Cara da Creatina</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="img/favicon.png" type="image/x-icon">
    <style>
        @font-face {
            font-family: 'Ambulance Shotgun';
            src: url('fonts/ambulance_shotgun.ttf') format('truetype'); /* Caminho para o arquivo da fonte */
        }

        body {
            margin: 0;
            background-color: #f5f5f5;
            color: #fff;
            font-family: 'Oswald', sans-serif;
        }

        /* Navbar */
        .navbar {
            background-color: #000;
            padding: 5px 20px; /* Navbar compacta */
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            font-size: 2rem !important; /* Tamanho padrão */
            color: #ffff !important; /* Texto vermelho */
            font-family: 'Ambulance Shotgun', sans-serif !important; /* Fonte personalizada */
            font-weight: 700;
            letter-spacing: 4px; 
        }

        .navbar-brand img {
            height: 50px; /* Tamanho da logo */
            margin-right: 15px; /* Espaçamento entre a logo e o texto */
        }

        .navbar-nav .nav-link {
            color: #fff;
            font-size: 1.1rem; /* Tamanho do texto dos links */
            padding: 6px 10px; /* Espaçamento reduzido entre os itens */
            font-weight: 600;
            text-transform: uppercase;
            transition: color 0.3s, border-bottom 0.3s;
        }

        .navbar-nav .nav-link:hover {
            color: #ff4c4c;
            border-bottom: 2px solid #ff4c4c;
        }

        /* Ajuste para telas pequenas */
        @media (max-width: 576px) {
            .navbar-brand {
                font-size: 1.6rem !important; /* Reduz o tamanho da fonte */
                letter-spacing: px; /* Ajusta o espaçamento entre letras */
            }

            .navbar-brand img {
                height: 40px; /* Reduz o tamanho da logo */
                margin-right: 10px; /* Reduz o espaçamento entre logo e texto */
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="img/logo1.png" alt="Logo O Cara da Creatina">
            
            </a>
                
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sobre.php">Sobre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contato.php">Contato</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
